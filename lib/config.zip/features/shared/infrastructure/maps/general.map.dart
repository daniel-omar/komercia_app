import 'package:flutter/material.dart';

final iconMap = {
  'attach_money': Icons.attach_money,
  'credit_card': Icons.credit_card,
  'account_balance': Icons.account_balance,
  'more_horiz': Icons.more_horiz,
};
