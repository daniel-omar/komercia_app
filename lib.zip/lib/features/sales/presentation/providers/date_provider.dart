import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:komercia_app/features/sales/domain/domain.dart';
import 'package:komercia_app/features/sales/infrastructure/infrastructure.dart';

final periodRepositoryProvider = Provider<PeriodRepository>((ref) {
  final periodRepository = PeriodRepositoryImpl(PeriodDatasourceImpl());
  return periodRepository;
});

final dateFilterProvider =
    StateNotifierProvider<DateFilterNotifier, DateFilterState>((ref) {
  final periodRepository = ref.watch(periodRepositoryProvider);

  return DateFilterNotifier(
    periodRepository: periodRepository,
    //idProductColor: idProductColor,
  ); // sin descuento por defecto
});

class DateFilterNotifier extends StateNotifier<DateFilterState> {
  final PeriodRepository periodRepository;

  DateFilterNotifier({
    required this.periodRepository,
    //required int? idProductColor,
  }) : super(DateFilterState()) {
    getDateToFilter();
  }

  Future<void> getDateToFilter() async {
    try {
      state = state.copyWith(isLoading: true);

      // Aquí haces la solicitud a la API que retorna todos los días, semanas, meses y años
      final response = await periodRepository.getToFilter();

      // Almacenas la respuesta en el estado
      state = DateFilterState(
        isLoading: false,
        dias: response.dias,
        semanas: response.semanas,
        meses: response.meses,
        anios: response.anios,
      );
    } catch (e) {
      print('Error fetching date filters: $e');
    }
  }
}

// Definición de la clase de estado
class DateFilterState {
  final bool isLoading;
  final List<Period> dias;
  final List<Period> semanas;
  final List<Period> meses;
  final List<Period> anios;

  DateFilterState({
    this.isLoading = false,
    this.dias = const [],
    this.semanas = const [],
    this.meses = const [],
    this.anios = const [],
  });

  DateFilterState copyWith(
          {bool? isLoading,
          List<Period>? dias,
          List<Period>? semanas,
          List<Period>? meses,
          List<Period>? anios}) =>
      DateFilterState(
          isLoading: isLoading ?? this.isLoading,
          dias: dias ?? this.dias,
          semanas: semanas ?? this.semanas,
          meses: meses ?? this.meses,
          anios: anios ?? this.anios);
}
