import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:komercia_app/features/sales/presentation/providers/date_provider.dart';

class BalanceScreen extends ConsumerWidget {
  const BalanceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dateFilter = ref.watch(dateFilterProvider);
    if (dateFilter.isLoading) {
      // Mostrar un loader mientras se obtienen los datos
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Balance'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_alt),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                builder: (_) => const _FilterOptions(),
              );
            },
          ),
        ],
      ),
      body: const Column(
        children: [
          _DateSelector(),
          _BalanceCard(),
          SizedBox(height: 10),
          _SalesList(),
        ],
      ),
      bottomNavigationBar: const _BottomActions(),
    );
  }
}

class _DateSelector extends StatelessWidget {
  const _DateSelector();

  @override
  Widget build(BuildContext context) {
    final dates = ['30 abr', '01 may', '02 may', '03 may'];

    return SizedBox(
      height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        itemCount: dates.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, index) {
          final date = dates[index];
          final isSelected = date == '02 may'; // ejemplo
          return ChoiceChip(
            label: Text(date),
            selected: isSelected,
            onSelected: (_) {
              // actualizar estado
            },
            selectedColor: Colors.yellow.shade700,
          );
        },
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Ingresos', style: TextStyle(fontWeight: FontWeight.bold)),
                Text('\$0'),
              ],
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                    onPressed: () {}, child: const Text('Descargar Reportes')),
                TextButton(onPressed: () {}, child: const Text('Ver Balance')),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _SalesList extends StatelessWidget {
  const _SalesList();

  @override
  Widget build(BuildContext context) {
    final sales = <String>[]; // aquí irían tus ventas

    if (sales.isEmpty) {
      return const Expanded(
        child: Column(
          children: [
            Icon(
              Icons.image_search_rounded,
              size: 100,
            ),
            SizedBox(height: 12),
            Text('No tienes registros creados en esta fecha.')
          ],
        ),
      );
    }

    return Expanded(
      child: ListView.builder(
        itemCount: sales.length,
        itemBuilder: (_, i) => ListTile(
          title: Text('Venta $i'),
          subtitle: Text('Detalle de la venta'),
        ),
      ),
    );
  }
}

class _BottomActions extends StatelessWidget {
  const _BottomActions();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Nueva venta'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.remove, color: Colors.white),
              label: const Text('Nuevo gasto'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterOptions extends StatelessWidget {
  const _FilterOptions();

  @override
  Widget build(BuildContext context) {
    final List<String> options = [
      'Hoy',
      'Esta semana',
      'Este mes',
      'Este año',
      'Personalizado'
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Elige el período que quieres ver:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              )
            ],
          ),
          const SizedBox(height: 10),
          ...options.map((option) => ListTile(
                title: Text(option),
                onTap: () {
                  // Aquí puedes manejar la lógica de filtrado real
                  Navigator.pop(context);
                },
              )),
        ],
      ),
    );
  }
}
