


class SaleNotFound implements Exception {}