class ResponseMain {
  int status;
  dynamic data;
  String message;

  ResponseMain(
      {required this.status, required this.data, required this.message});
}
