export 'email.dart';
export 'password.dart';
export 'price.dart';
export 'slug.dart';
export 'stock.dart';
export 'title.dart';
export 'phone.dart';
