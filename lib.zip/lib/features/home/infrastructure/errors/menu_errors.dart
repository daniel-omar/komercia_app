


class ProductNotFound implements Exception {}